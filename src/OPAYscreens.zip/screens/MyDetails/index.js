import React from 'react';
import {
  View,
  TouchableOpacity,
  Image,
  StyleSheet,
  StatusBar,
} from 'react-native';
import Header from 'comp/Header';
import TextView from 'comp/TextView';
import R from 'res/R';
import {
  scale,
  verticalScale,
  textScale,
  moderateScale,
} from '../../res/responsiveStyle/responsiveStyle';
import {RFValue} from 'react-native-responsive-fontsize';
const MenuBtn = ({onPressAction, title, value}) => {
  return (
    <TouchableOpacity
      onPress={onPressAction}
      style={{padding: 10, flexDirection: 'row'}}>
      <View style={{padding: 10, flex: 5}}>
        <TextView
          textValue={value}
          textStyle={{
            fontFamily: 'OpenSans-Bold',
            fontWeight: 'bold',
            color: '#636363',
            fontSize: 16,
          }}
        />
        <TextView
          textValue={title}
          textStyle={{
            fontFamily: 'OpenSans-Bold',
            fontWeight: 'bold',
            color: '#bbbbbb',
            fontSize: 14,
          }}
        />
      </View>
      <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
        <Image
          style={{transform: [{rotateY: '180deg'}]}}
          source={R.Images.backArrow}
        />
      </View>
      <View
        style={{position: 'absolute', bottom: 0, height: 1, left: 0, right: 0}}>
        <View
          style={{
            width: '100%',
            height: verticalScale(1),
            backgroundColor: '#bbbbbb',
            borderWidth: 0,
            opacity: 0.4,
            marginLeft: moderateScale(20),
          }}
        />
      </View>
    </TouchableOpacity>
  );
};

export default class MyDetails extends React.Component {
  constructor() {
    super();
    this.state = {
      firstName: 'Alex',
      midName: 'Thomas',
      lastName: 'Rankin',
      mobileNum: '04 xxxxx 678',
    };
  }
  render() {
    return (
      <View style={{flex: 1, backgroundColor: '#fff'}}>
        <StatusBar
          translucent={true}
          barStyle="dark-content"
          backgroundColor={R.color.appTheme}
          hidden={false}
        />
        <Header
          title="My details"
          showBackButton={true}
          backPress={() => this.props.navigation.goBack(null)}
        />
        <View
          style={{
            width: '100%',
            height: verticalScale(1),
            backgroundColor: '#bbbbbb',
            borderWidth: 0,
            opacity: 0.4,
          }}
        />
        <MenuBtn
          title={'Full Name'}
          value={
            this.state.firstName +
            ' ' +
            this.state.midName +
            ' ' +
            this.state.lastName
          }
          onPressAction={() =>
            this.props.navigation.navigate('EditDetails', {
              data: 'name',
              firstName: this.state.firstName,
              midName: this.state.midName,
              lastName: this.state.lastName,
            })
          }
        />
        <MenuBtn
          title={'Mobile'}
          value={this.state.mobileNum}
          onPressAction={() =>
            this.props.navigation.navigate('EditPhone', {
              data: 'mobile',
              number: this.state.mobileNum,
            })
          }
        />
        <MenuBtn
          title={'Address'}
          value={'xxxxx Victoria 3031'}
          onPressAction={() =>
            this.props.navigation.navigate('EditAddress', {
              data: 'address',
              address: 'xxxxx Victoria 3031',
            })
          }
        />
        <MenuBtn
          title={'Email'}
          value={'alex.rankins@gmail.com'}
          onPressAction={() =>
            this.props.navigation.navigate('EditEmail', {
              data: 'email',
              email: 'alex.rankins@gmail.com',
            })
          }
        />
      </View>
    );
  }
}
