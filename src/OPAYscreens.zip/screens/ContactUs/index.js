import React from 'react';
import {Linking, SafeAreaView, View, Text, StatusBar} from 'react-native';
import Header from '../../res/components/Header';
import R from 'res/R';
export default class TermsPrivacy extends React.Component {
  render() {
    return (
      <SafeAreaView style={{flex: 1, backgroundColor: 'white'}}>
        <StatusBar
          translucent={true}
          barStyle="dark-content"
          backgroundColor={R.color.appTheme}
          hidden={false}
        />
        <View style={{backgroundColor: 'white'}}>
          <Header
            title={'Contact us'}
            showBackButton={true}
            backPress={() => this.props.navigation.goBack(null)}
          />
        </View>
        <View
          style={{
            marginTop: '40%',
            alignItems: 'center',
            justifyContent: 'center',
            marginHorizontal: '10%',
          }}>
          <Text
            style={{
              fontFamily: 'OpenSans-Regular',
              textAlign: 'center',
              fontSize: 16,
              lineHeight: 20,
            }}>
            We’d love to hear any feedback or questions you may have. Please
            contact us at
            <Text
              onPress={() => Linking.openURL('mailto:info@doshy.com.au')}
              style={{fontSize: 16, color: '#4083FF'}}>
              {' '}
              info@doshy.com.au
            </Text>
          </Text>
        </View>
      </SafeAreaView>
    );
  }
}
