import React from 'react';
import Header from 'comp/Header';
import {View, StatusBar} from 'react-native';
import InputOTP from 'screens/ResetPIN/InputOTP';
import ResetPINScreen from 'screens/ResetPIN/ResetPINScreen';
import Utils from 'res/Utils';
import R from 'res/R';

export default class ResetPIN extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selTab: 1,
      mobileNum: '1234567890',
    };
  }

  componentDidMount() {
    Utils.getData(
      'UserData',
      (value = (data) => {
        let UserData = JSON.parse(data.value);
        console.log(UserData.mobile);
        let input = {
          mobile: UserData.mobile,
        };
      }),
    );
  }

  checkInputOTP(data) {
    this.setState({selTab: 2}, () => console.log(data));
  }

  newPinInputProp() {
    this.props.navigation.reset({
      routes: [{name: this.props.route.params.from}],
    });
  }

  renderTab() {
    if (this.state.selTab == 1) {
      return (
        <InputOTP
          mobileNumProp={this.state.mobileNum}
          pinInputProp={(data) => this.checkInputOTP(data)}
        />
      );
    }
    if (this.state.selTab == 2) {
      return (
        <ResetPINScreen newPinInputProp={this.newPinInputProp.bind(this)} />
      );
    }
  }

  render() {
    console.log(this.props.route.params.from);
    return (
      <View style={{flex: 1, backgroundColor: '#fff'}}>
        <StatusBar
          translucent={true}
          barStyle="dark-content"
          backgroundColor={R.color.appTheme}
          hidden={false}
        />
        <Header
          title={`Reset PIN (${this.state.selTab} of 2)`}
          showExtraBtn={this.state.selTab == 1 ? true : false}
          extraBtnText={'Resend code'}
          extraBtnPress={() => {}}
          crossEnable={true}
          showBackButton={true}
          backPress={() => this.props.navigation.goBack(null)}
        />

        {this.renderTab()}
      </View>
    );
  }
}
